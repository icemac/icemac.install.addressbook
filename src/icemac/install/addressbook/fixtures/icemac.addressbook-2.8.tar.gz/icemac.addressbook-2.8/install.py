import sys

filename = sys.stdin.readline()
filename = 'foo'
with open(filename, 'w') as f:
    f.write('created by install.py')
